libdsp
======

This directory contains various DSP functions.

At the moment you will find here mainly functions related to BLDC/PMSM control.
